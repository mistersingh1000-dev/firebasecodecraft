const firebaseConfig = {
    projectId: "codecraftmarketing-in",
    appId: "1:569222123562:web:4d3f88c4dc9d37d6a73353",
    storageBucket: "codecraftmarketing-in.appspot.com",
    apiKey: "AIzaSyBqhhPQim9mHhAkqiR-DhPAZOrAzPiG6gs",
    authDomain: "codecraftmarketing-in.firebaseapp.com",
    messagingSenderId: "569222123562"
};

export default firebaseConfig;
